<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/e59b510569.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/stylesheet.css">
    <title>library management system</title>
  </head>
  <body>
  <div class=p-3>
 
  <div class="float-left">
    <img src="../images/logo1.png" width=50px height=50px>
    </div>
    <h1 style="color: #e5a55c;">Library Management System</h1>
    </div>
    <nav class="navbar navbar-expand-lg bg-dark">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    
     <marquee> <em >
      <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link text-white" href="#"><span style="font-size:23px";>Welcome</span></a>
      </li>
     
      <li class="nav-item">
      <div style="margin-top: 0px; font-size:23px";>
        <a class="nav-link text-white" href=""><img 
		class="rounded-circle"
         src="<?php
                      include_once('../connection.php');
                     $res=mysqli_query($conn,"select photo from userinfo where email='$_SESSION[email]'");
                     while($row1=mysqli_fetch_array($res))
                        {$photo=$row1["photo"];}
        echo $photo;?>" /><?php echo"$_SESSION[email]";?></a>
    </div>
      </li>
      </div>
      </ul></em></marquee>
</nav>
<div class="container-fluid mt-3">
<a href="profile.php"><button type="button" class="btn btn-primary">PROFILE</button></a>
 <a href="user.php"><button type="button" class="btn btn-primary">UPDATE INFO</button></a>
 <a href="sbookinfo.php"><button type="button" class="btn btn-primary">BOOKS INFO</button></a>
 <a href="issuedbooks.php"><button type="button" class="btn btn-primary">ISSUED BOOKS</button></a>
 <a href="spass.php"><button type="button" class="btn btn-success">CHANGE PASSWORD</button></a>
<a href="slogout.php"><button type="button" class="btn btn-danger">LOGOUT</button></a>
</div>
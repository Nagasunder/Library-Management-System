<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/e59b510569.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/stylesheet.css">
    <title>library management system</title>
  </head>
  <body>
  <div class=p-3>
  
  <div class="float-left">
    <img src="../images/logo1.png" width=50px height=50px>
    </div>
    <h1 style="color: #e5a55c;">Library Management System</h1>
</div>
    <nav class="navbar navbar-expand-lg bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
 
</nav>
<div class="container-fluid p-3">
  <a href="librarian.php"><button type="button" class="btn btn-primary">ADD BOOKS</button></a>  
  <a href="issuebooks.php"><button type="button" class="btn btn-primary">ISSUE BOOKS</button></a>
  <a href="returnbook.php"><button type="button" class="btn btn-primary">RETURN BOOKS</button></a>
  <a href="booksinfo.php"><button type="button" class="btn btn-primary">BOOKS INFO</button></a>
<a href="lsinfo.php"><button type="button" class="btn btn-primary">USER DATA</button></a>
<a href="lpass.php"><button type="button" class="btn btn-success">change password</button></a>
<a href="../users/slogout.php"><button type="button" class="btn btn-danger">logout</button></a>
</div>
<!doctype html>
<html lang="en">
  <head>
      <!-- Required meta tags -->
    <meta charset="utf-8">
   <!-- <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">-->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/e59b510569.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/stylesheet.css">
    <title>library management system</title>
  </head>
  <body>
  <div >
  
  <div >
  
    <img src="images/logo1.png" style="height: 80px;width: 80px;"> 
    </div>
	<a href="index.php">
    <h1 style="
    color: #e5a55c;line-height: 1.5!important;    margin-left: 6rem;  margin-top: -5rem;">Library Management System</h1>
	</a>
</div>
  